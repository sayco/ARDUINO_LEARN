Codeacademy-theme
=================

This is Codeacademy.com color scheme based theme for Sublime Text 2/Textmate.

## Design

CSS -
![css](https://raw.github.com/DenimTornado/Codeacademy-theme/master/images/css.png)

HTML -
![html](https://raw.github.com/DenimTornado/Codeacademy-theme/master/images/html.png)

JS -
![js](https://raw.github.com/DenimTornado/Codeacademy-theme/master/images/js.png)

PHP -
![php](https://raw.github.com/DenimTornado/Codeacademy-theme/master/images/php.png)

## Installation

Put "Codeacademy.tmTheme" into your /Packages/User/tmtheme and than choose it through  Preferences/Color Scheme/User/Codeacademy.tmTheme